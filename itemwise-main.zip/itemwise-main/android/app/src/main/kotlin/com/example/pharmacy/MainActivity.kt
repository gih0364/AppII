package com.example.pharmacy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
