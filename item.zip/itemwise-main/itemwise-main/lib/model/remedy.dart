class Remedy {
  String remedyName;
  String remedyDescription;

  int? grams;

  Remedy({
    required this.remedyName,
    required this.remedyDescription,
  
    this.grams,
  });
}
